<?php

/**
 * Plugin Name: SVGFavicon 
 * Plugin URI:  https://github.com/boostemaboite/SVGFavicon
 * Description: Add an SVG Favicon to your WordPress site
 * Version: 1.0.0
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author: Boostemaboite
 * Author URI: https://boostemaboite.dev
 * License: GNU General Public License v2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: SVGFavicon
 * Domain Path: /languages/
 */

// General direct file access security
if (!defined('WPINC')) die;

add_action('wp_head', 'enqueueFavicon');

/* Describe what the code snippet does so you can remember later on */
function enqueueFavicon()
{
?>
    <link rel="icon" href=" <?php . plugin_dir_url(__FILE__) . ?> "favicon.svg" type="image/svg+xml">
<?php
};
 